package com.example.mars_farhan3tie.Pertemuan3
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.Pertemuan3.ThirdResultActivity
import com.example.mars_farhan3tie.databinding.ActivityThirdBinding
import kotlin.jvm.java

class ThirdActivity : AppCompatActivity() {

    private lateinit var binding: ActivityThirdBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityThirdBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Perintah untuk pindah halaman saat tombol diklik
        binding.btnKirim.setOnClickListener {
            val intent = Intent(this, ThirdResultActivity::class.java)
            startActivity(intent)
        }
    }
}